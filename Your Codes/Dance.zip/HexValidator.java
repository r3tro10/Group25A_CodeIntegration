/**
 * HexValidator.java
 *
 * Provides static methods to validate hexadecimal string input
 * according to the Task 9 rules:
 *   - 1 or 2 characters long
 *   - Each character must be 0–9 or A–F (case insensitive)
 */
public class HexValidator {
 
    /**
     * Returns true if the supplied string is a valid hexadecimal value.
     * A valid value is 1-2 characters, each being 0-9 or A-F (case insensitive).
     *
     * @param hex The string to validate.
     * @return true if valid, false otherwise.
     */
    public static boolean isValid(String hex) {
        if (hex == null) return false;
 
        String trimmed = hex.trim();
        if (trimmed.length() < 1 || trimmed.length() > 2) return false;
 
        for (int i = 0; i < trimmed.length(); i++) {
            char c = trimmed.charAt(i);
            // Convert lower-case letters to upper-case manually
            if (c >= 'a' && c <= 'f') {
                c = (char) (c - 32);
            }
            boolean isDigit = (c >= '0' && c <= '9');
            boolean isHexLetter = (c >= 'A' && c <= 'F');
            if (!isDigit && !isHexLetter) {
                return false;
            }
        }
        return true;
    }
 
    /**
     * Returns a human-readable reason explaining why a value is invalid.
     * Useful for displaying informative error messages to the user.
     *
     * @param hex The invalid string.
     * @return A descriptive reason string.
     */
    public static String getInvalidReason(String hex) {
        if (hex == null || hex.trim().isEmpty()) {
            return "empty value";
        }
        String trimmed = hex.trim();
 
        if (trimmed.length() > 2) {
            return "more than 2 characters (" + trimmed.length() + " given)";
        }
 
        for (int i = 0; i < trimmed.length(); i++) {
            char c = trimmed.charAt(i);
            char upper = c;
            if (c >= 'a' && c <= 'z') {
                upper = (char) (c - 32);
            }
            boolean isDigit = (upper >= '0' && upper <= '9');
            boolean isHexLetter = (upper >= 'A' && upper <= 'F');
            if (!isDigit && !isHexLetter) {
                return "contains invalid character '" + c + "' (only 0-9 and A-F are allowed)";
            }
        }
        return "unknown reason";
    }
}
