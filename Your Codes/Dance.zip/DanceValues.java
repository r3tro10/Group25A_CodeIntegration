/**
 * DanceValues.java
 *
 * A data-holding class (value object) that stores all computed parameters
 * for a single hexadecimal input: its number-system equivalents, the
 * SwiftBot speed, and the LED RGB colour values.
 *
 * Instances are immutable once constructed.
 */
public class DanceValues {
 
    private final String hex;     // Original hex string (upper-case)
    private final int decimal;    // Decimal equivalent
    private final int octal;      // Octal equivalent (as an integer, e.g. 132 for 90 decimal)
    private final String binary;  // Binary string (e.g. "1011010")
    private final int speed;      // Calculated SwiftBot wheel speed
    private final int redLED;     // LED red component   (0-255)
    private final int greenLED;   // LED green component (0-255)
    private final int blueLED;    // LED blue component  (0-255)
 
    /**
     * Constructs a DanceValues object with all pre-computed parameters.
     */
    public DanceValues(String hex, int decimal, int octal, String binary,
                       int speed, int redLED, int greenLED, int blueLED) {
        this.hex      = hex;
        this.decimal  = decimal;
        this.octal    = octal;
        this.binary   = binary;
        this.speed    = speed;
        this.redLED   = redLED;
        this.greenLED = greenLED;
        this.blueLED  = blueLED;
    }
 
    // -------------------------------------------------------------------------
    // Getters
    // -------------------------------------------------------------------------
 
    public String getHex()      { return hex; }
    public int getDecimal()     { return decimal; }
    public int getOctal()       { return octal; }
    public String getBinary()   { return binary; }
    public int getSpeed()       { return speed; }
    public int getRedLED()      { return redLED; }
    public int getGreenLED()    { return greenLED; }
    public int getBlueLED()     { return blueLED; }
 
    /**
     * Returns true if the original hexadecimal value was 2 digits long.
     * This determines forward-movement duration (0.5s vs 1.0s).
     */
    public boolean isTwoDigit() {
        return hex.length() == 2;
    }
 
    /**
     * Returns the forward-movement duration in milliseconds.
     *   - 2-digit hex → 500 ms
     *   - 1-digit hex → 1000 ms
     */
    public int getForwardDurationMs() {
        return isTwoDigit() ? 500 : 1000;
    }
 
    /**
     * Produces a formatted summary string matching the required output format, e.g.:
     *   "F, 17, 15, 1111, speed = 67, LED colour (red 15, green 45, blue 45)."
     */
    @Override
    public String toString() {
        return hex + ", " + octal + ", " + decimal + ", " + binary
             + ", speed = " + speed
             + ", LED colour (red " + redLED
             + ", green " + greenLED
             + ", blue " + blueLED + ").";
    }
}
