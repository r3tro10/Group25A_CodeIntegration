	/**
	 * NumberConverter.java
	 * 
	 * Provides custom algorithms for converting between number systems.
	 * No Java built-in conversion methods are used (e.g., Integer.parseInt,
	 * Integer.toBinaryString, etc.) in compliance with the task requirements.
	 */
	public class NumberConverter {
	 
	    // -------------------------------------------------------------------------
	    // Hexadecimal → Decimal
	    // -------------------------------------------------------------------------
	 
	    /**
	     * Converts a hexadecimal string to its decimal (base-10) integer value.
	     * Algorithm: Iterate left to right, accumulate result = result * 16 + digit.
	     *
	     * @param hex A valid 1-2 character hexadecimal string (0-9, A-F, case insensitive).
	     * @return The decimal equivalent.
	     */
	    public static int hexToDecimal(String hex) {
	        String upper = toUpperCase(hex);
	        int decimal = 0;
	        for (int i = 0; i < upper.length(); i++) {
	            char c = upper.charAt(i);
	            int digitValue = hexCharToInt(c);
	            decimal = decimal * 16 + digitValue;
	        }
	        return decimal;
	    }
	 
	    // -------------------------------------------------------------------------
	    // Decimal → Binary
	    // -------------------------------------------------------------------------
	 
	    /**
	     * Converts a non-negative decimal integer to its binary (base-2) string.
	     * Algorithm: Repeatedly divide by 2, collect remainders, reverse.
	     *
	     * @param decimal A non-negative integer.
	     * @return The binary string representation (e.g., "1011010" for 90).
	     */
	    public static String decimalToBinary(int decimal) {
	        if (decimal == 0) {
	            return "0";
	        }
	        String binary = "";
	        int n = decimal;
	        while (n > 0) {
	            int remainder = n % 2;
	            binary = remainder + binary; // prepend bit
	            n = n / 2;
	        }
	        return binary;
	    }
	 
	    // -------------------------------------------------------------------------
	    // Decimal → Octal  (returned as an int whose digits ARE the octal digits)
	    // -------------------------------------------------------------------------
	 
	    /**
	     * Converts a non-negative decimal integer to its octal (base-8) equivalent,
	     * returned as an integer whose digits represent the octal value.
	     * Algorithm: Repeatedly divide by 8, build the octal number digit by digit.
	     * Example: 90 decimal → 132 (octal digits: 1, 3, 2).
	     *
	     * @param decimal A non-negative integer.
	     * @return The octal representation as an integer (e.g., 132 for 90).
	     */
	    public static int decimalToOctal(int decimal) {
	        if (decimal == 0) {
	            return 0;
	        }
	        int octal = 0;
	        int multiplier = 1; // position multiplier (1, 10, 100, …)
	        int n = decimal;
	        while (n > 0) {
	            int remainder = n % 8;
	            octal += remainder * multiplier;
	            n = n / 8;
	            multiplier *= 10;
	        }
	        return octal;
	    }
	 
	    // -------------------------------------------------------------------------
	    // Helpers
	    // -------------------------------------------------------------------------
	 
	    /**
	     * Converts a single hexadecimal character ('0'-'9', 'A'-'F') to its integer value.
	     * Must only be called with characters already validated/uppercased.
	     */
	    private static int hexCharToInt(char c) {
	        if (c >= '0' && c <= '9') {
	            return c - '0';
	        } else if (c >= 'A' && c <= 'F') {
	            return c - 'A' + 10;
	        }
	        throw new IllegalArgumentException("Invalid hex character: " + c);
	    }
	 
	    /**
	     * Converts a string to upper case without using String.toUpperCase() internally
	     * in a way that relies on locale — here we do simple ASCII upper-casing.
	     */
	    private static String toUpperCase(String s) {
	        char[] chars = s.toCharArray();
	        for (int i = 0; i < chars.length; i++) {
	            if (chars[i] >= 'a' && chars[i] <= 'f') {
	                chars[i] = (char) (chars[i] - 32);
	            }
	        }
	        return new String(chars);
	    }
	}