import swiftbot.SwiftBotAPI;
import swiftbot.Underlight;
 
/**
 * DanceController.java
 *
 * Handles all physical interaction with the SwiftBot: setting underlight
 * colours and executing the movement sequences derived from binary values.
 *
 * Movement rules (binary read right-to-left):
 *   '1' → move FORWARD  (duration depends on 1- or 2-digit hex)
 *   '0' → SPIN          (fixed 500 ms spin)
 */
public class DanceController {
 
    /** Duration of a single spin move in milliseconds. */
    private static final int SPIN_DURATION_MS = 500;
 
    private final SwiftBotAPI swiftBot;
 
    /**
     * Constructs a DanceController with a live SwiftBotAPI instance.
     *
     * @param swiftBot An initialised SwiftBotAPI.
     */
    public DanceController(SwiftBotAPI swiftBot) {
        this.swiftBot = swiftBot;
    }
 
    // -------------------------------------------------------------------------
    // Public API
    // -------------------------------------------------------------------------
 
    /**
     * Executes a complete dance routine for one set of DanceValues:
     *   1. Activates underlights with the computed RGB colour.
     *   2. Reads the binary string right-to-left.
     *   3. Moves forward ('1') or spins ('0') for each bit.
     *
     * @param values The pre-computed dance parameters.
     */
    public void executeDanceRoutine(DanceValues values) {
        printRoutineHeader(values);
 
        // Activate underlights
        int[] rgb = { values.getRedLED(), values.getGreenLED(), values.getBlueLED() };
        swiftBot.fillUnderlights(rgb);
 
        // Read binary right-to-left
        String binary = values.getBinary();
        int forwardMs  = values.getForwardDurationMs();
        int speed      = values.getSpeed();
 
        for (int i = binary.length() - 1; i >= 0; i--) {
            char bit = binary.charAt(i);
            if (bit == '1') {
                moveForward(speed, forwardMs);
            } else {
                spin(speed);
            }
        }
 
        System.out.println("    [Routine for " + values.getHex() + " complete]");
    }
 
    /**
     * Switches off all underlights.
     * Call this after the final routine in a session.
     */
    public void disableAllLights() {
        swiftBot.disableUnderlights();
    }
 
    // -------------------------------------------------------------------------
    // Movement helpers
    // -------------------------------------------------------------------------
 
    /**
     * Moves the SwiftBot straight forward.
     *
     * @param speed      Wheel speed (0-100).
     * @param durationMs Duration in milliseconds.
     */
    private void moveForward(int speed, int durationMs) {
        System.out.println("    -> FORWARD (" + (durationMs / 1000.0) + "s) at speed " + speed);
        swiftBot.move(speed, speed, durationMs);
    }
 
    /**
     * Spins the SwiftBot on the spot (clockwise).
     * Left wheel forward, right wheel backward at the same speed.
     *
     * @param speed Wheel speed (0-100).
     */
    private void spin(int speed) {
        System.out.println("    -> SPIN (0.5s) at speed " + speed);
        swiftBot.move(speed, -speed, SPIN_DURATION_MS);
    }
 
    // -------------------------------------------------------------------------
    // Display helpers
    // -------------------------------------------------------------------------
 
    private void printRoutineHeader(DanceValues values) {
        System.out.println();
        System.out.println("  ► Executing routine for hex: " + values.getHex());
        System.out.println("    Speed   : " + values.getSpeed());
        System.out.println("    LEDs    : R=" + values.getRedLED()
                + "  G=" + values.getGreenLED()
                + "  B=" + values.getBlueLED());
        System.out.println("    Binary  : " + values.getBinary()
                + "  (read right→left)");
        System.out.println("    Moves   : " + buildMoveSequence(values.getBinary()));
    }
 
    /**
     * Builds a human-readable move sequence string from a binary value.
     * Example: "1011010" → "SPIN FWD SPIN FWD FWD SPIN FWD"
     */
    private String buildMoveSequence(String binary) {
        StringBuilder sb = new StringBuilder();
        for (int i = binary.length() - 1; i >= 0; i--) {
            if (sb.length() > 0) sb.append(" ");
            sb.append(binary.charAt(i) == '1' ? "FWD" : "SPIN");
        }
        return sb.toString();
    }

	/**
	 * Builds a human-readable move sequence string from a binary value.
	 * Example: "1011010" → "SPIN FWD SPIN FWD FWD SPIN FWD"
	 */
	private String buildMoveSequence(String binary) {
	    StringBuilder sb = new StringBuilder();
	    for (int i = binary.length() - 1; i >= 0; i--) {
	        if (sb.length() > 0) sb.append(" ");
	        sb.append(binary.charAt(i) == '1' ? "FWD" : "SPIN");
	    }
	    return sb.toString();
	}
}
