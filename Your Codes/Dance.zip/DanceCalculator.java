/**
 * DanceCalculator.java
 *
 * Responsible for computing all dance parameters (speed, LED colour) from
 * the number-system conversions of a hexadecimal input, and for building
 * a complete {@link DanceValues} object ready for the controller.
 *
 * Speed rules (based on octal value):
 *   - If octal < 50      → speed = octal + 50
 *   - If octal > MAX     → speed = MAX
 *   - Otherwise          → speed = octal
 *
 * LED rules (based on decimal value):
 *   - red   = decimal
 *   - green = (decimal mod 80) × 3
 *   - blue  = max(red, green)
 */
public class DanceCalculator {
 
    /** Maximum wheel speed allowed by the SwiftBot hardware. */
    public static final int MAX_SPEED = 100;
 
    // -------------------------------------------------------------------------
    // Main factory method
    // -------------------------------------------------------------------------
 
    /**
     * Converts a validated, upper-cased hexadecimal string into a fully
     * populated {@link DanceValues} object.
     *
     * @param hex A valid 1-2 character hex string (upper-case).
     * @return    A {@code DanceValues} containing all computed parameters.
     */
    public static DanceValues compute(String hex) {
        // --- Number conversions (custom algorithms – no built-ins) ---
        int decimal  = NumberConverter.hexToDecimal(hex);
        int octal    = NumberConverter.decimalToOctal(decimal);
        String binary = NumberConverter.decimalToBinary(decimal);
 
        // --- Speed calculation ---
        int speed = calculateSpeed(octal);
 
        // --- LED colour calculation ---
        int red   = calculateRed(decimal);
        int green = calculateGreen(decimal);
        int blue  = calculateBlue(red, green);
 
        return new DanceValues(hex, decimal, octal, binary, speed, red, green, blue);
    }
 
    // -------------------------------------------------------------------------
    // Speed helpers
    // -------------------------------------------------------------------------
 
    /**
     * Applies the speed rules to the octal value.
     *
     * @param octal The octal representation of the hex input (as an int).
     * @return      The final SwiftBot speed (clamped to MAX_SPEED).
     */
    public static int calculateSpeed(int octal) {
        int speed = octal;
        if (speed < 50) {
            speed = speed + 50;
        }
        if (speed > MAX_SPEED) {
            speed = MAX_SPEED;
        }
        return speed;
    }
 
    // -------------------------------------------------------------------------
    // LED helpers
    // -------------------------------------------------------------------------
 
    /**
     * Red component = decimal equivalent.
     * (Maximum possible: 0xFF = 255, safely within 0-255 range.)
     */
    public static int calculateRed(int decimal) {
        return decimal;
    }
 
    /**
     * Green component = (decimal mod 80) × 3.
     * Maximum: 79 × 3 = 237, safely within 0-255 range.
     */
    public static int calculateGreen(int decimal) {
        return (decimal % 80) * 3;
    }
 
    /**
     * Blue component = the greater of red and green.
     * Implemented without Math.max to keep to plain arithmetic.
     */
    public static int calculateBlue(int red, int green) {
        return (red >= green) ? red : green;
    }
}
