import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
 
/**
 * SessionManager.java
 *
 * Tracks all valid hexadecimal values entered across every QR-code scan in
 * the current session.  On program termination it sorts them in ascending
 * order (by decimal value) using a custom bubble-sort algorithm and writes
 * them to a plain-text log file.
 */
public class SessionManager {
 
    private final List<String> allHexValues;
 
    public SessionManager() {
        this.allHexValues = new ArrayList<>();
    }
 
    // -------------------------------------------------------------------------
    // Accumulation
    // -------------------------------------------------------------------------
 
    /**
     * Records a valid hexadecimal string (upper-cased) for later logging.
     *
     * @param hex A validated, upper-cased hex string.
     */
    public void addHexValue(String hex) {
        allHexValues.add(hex.toUpperCase());
    }
 
    /** @return An unmodifiable view of all accumulated hex values. */
    public List<String> getAllHexValues() {
        return new ArrayList<>(allHexValues);
    }
 
    // -------------------------------------------------------------------------
    // Save to file
    // -------------------------------------------------------------------------
 
    /**
     * Sorts all accumulated hex values in ascending order (by their decimal
     * equivalent) using a custom bubble-sort, then writes them to a text file.
     *
     * @return The absolute path of the file that was written, or {@code null}
     *         if writing failed.
     */
    public String saveToFile() {
        if (allHexValues.isEmpty()) {
            System.out.println("No hexadecimal values to save.");
            return null;
        }
 
        // Copy and sort
        List<String> sorted = new ArrayList<>(allHexValues);
        bubbleSortByDecimalValue(sorted);
 
        // Build file path in the working directory
        String fileName = "swiftbot_hex_values.txt";
        File file = new File(fileName);
 
        try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
            writer.println("SwiftBot Dance Program – Session Log");
            writer.println("=====================================");
            writer.println("Hexadecimal values (ascending order):");
            writer.println();
            for (String hex : sorted) {
                writer.println(hex);
            }
            writer.println();
            writer.println("Total: " + sorted.size() + " value(s)");
        } catch (IOException e) {
            System.out.println("ERROR: Could not write log file – " + e.getMessage());
            return null;
        }
 
        return file.getAbsolutePath();
    }
 
    // -------------------------------------------------------------------------
    // Custom sorting algorithm
    // -------------------------------------------------------------------------
 
    /**
     * Sorts a list of hex strings in ascending order of their decimal value
     * using a custom bubble-sort (no Collections.sort or Arrays.sort).
     *
     * @param list The list to sort in-place.
     */
    private void bubbleSortByDecimalValue(List<String> list) {
        int n = list.size();
        boolean swapped;
        for (int pass = 0; pass < n - 1; pass++) {
            swapped = false;
            for (int i = 0; i < n - pass - 1; i++) {
                int val1 = NumberConverter.hexToDecimal(list.get(i));
                int val2 = NumberConverter.hexToDecimal(list.get(i + 1));
                if (val1 > val2) {
                    // Swap
                    String temp = list.get(i);
                    list.set(i, list.get(i + 1));
                    list.set(i + 1, temp);
                    swapped = true;
                }
            }
            // If no swap occurred in this pass the list is already sorted
            if (!swapped) break;
        }
    }
}
