	import swiftbot.Button;
	import swiftbot.ButtonFunction;
	import swiftbot.ImageSize;
	import swiftbot.SwiftBotAPI;

	import java.awt.image.BufferedImage;
	import java.util.ArrayList;
	import java.util.List;
	import java.util.Scanner;

	/**
	 * Task9Dance.java  –  Main class for CS1813 Task 9: Dance
	 * =========================================================
	 *
	 * Program flow:
	 *   1. Initialise SwiftBot.
	 *   2. Display startup screen.
	 *   3. Prompt user to scan a QR code containing 1-5 hexadecimal values.
	 *   4. Validate each value; notify user of any ignored ones.
	 *   5. (A* feature) Ask user for a repetition multiplier (1-3).
	 *   6. Compute and display conversions, speed, and LED colour for each value.
	 *   7. Execute dance routines in sequence (repeated if multiplier > 1).
	 *   8. Turn off LEDs; ask user to press Y (continue) or X (exit).
	 *   9. On exit: sort all session hex values, save to file, display path.
	 *
	 * A* Feature – Dance Repetition Multiplier:
	 *   After a valid QR scan the user is prompted to enter a number 1-3.
	 *   Every dance routine in that round is repeated that many times.
	 *   This accepts user input, performs meaningful processing, and directly
	 *   affects SwiftBot movement duration and behaviour.
	 */
	public class Task9Dance {

	    // -------------------------------------------------------------------------
	    // Constants
	    // -------------------------------------------------------------------------

	    private static final int MAX_HEX_VALUES_PER_SCAN = 5;

	    // -------------------------------------------------------------------------
	    // Shared state
	    // -------------------------------------------------------------------------

	    private static SwiftBotAPI      swiftBot;
	    private static SessionManager   sessionManager;
	    private static DanceController  danceController;
	    private static Scanner          keyboard;

	    /** Volatile so it is safely visible to the button-callback thread. */
	    private static volatile char    userButtonChoice = '\0';

	    // -------------------------------------------------------------------------
	    // Entry point
	    // -------------------------------------------------------------------------

	    public static void main(String[] args) {

	        keyboard       = new Scanner(System.in);
	        sessionManager = new SessionManager();

	        // Initialise SwiftBot
	        System.out.println("Initialising SwiftBot…");
	        try {
	            swiftBot       = new SwiftBotAPI();
	            danceController = new DanceController(swiftBot);
	        } catch (Exception e) {
	            System.out.println("FATAL: Could not initialise SwiftBot – " + e.getMessage());
	            return;
	        }

	        displayStartupScreen();

	        // -------------------------------------------------------------------------
	        // Main program loop
	        // -------------------------------------------------------------------------
	        boolean running = true;
	        while (running) {

	            // --- Step 1: Scan QR code ---
	            String rawInput = scanQRCode();
	            if (rawInput == null || rawInput.trim().isEmpty()) {
	                System.out.println("Could not read a QR code. Please try again.\n");
	                continue;
	            }

	            System.out.println("\n================================================");
	            System.out.println("              QR CODE SCAN RESULT");
	            System.out.println("================================================");
	            System.out.println("Scanned Input: " + rawInput);
	            System.out.println("------------------------------------------------");

	            // --- Step 2: Split and validate ---
	            String[] parts = rawInput.split("&");

	            // Warn if more than 5 values supplied; only process the first 5
	            if (parts.length > MAX_HEX_VALUES_PER_SCAN) {
	                System.out.println("WARNING: " + parts.length + " values found."
	                        + " Only the first " + MAX_HEX_VALUES_PER_SCAN + " will be processed.");
	                String[] trimmed = new String[MAX_HEX_VALUES_PER_SCAN];
	                for (int i = 0; i < MAX_HEX_VALUES_PER_SCAN; i++) {
	                    trimmed[i] = parts[i];
	                }
	                parts = trimmed;
	            }

	            List<String> validHex   = new ArrayList<>();
	            List<String> ignoredHex = new ArrayList<>();

	            for (String part : parts) {
	                String s = part.trim();
	                if (HexValidator.isValid(s)) {
	                    validHex.add(s.toUpperCase());
	                } else {
	                    ignoredHex.add(s);
	                }
	            }

	            // Report ignored values
	            if (!ignoredHex.isEmpty()) {
	                System.out.println("\nIGNORED INVALID VALUES:");
	                for (String bad : ignoredHex) {
	                    System.out.println("  \"" + bad + "\"  →  "
	                            + HexValidator.getInvalidReason(bad));
	                }
	            }

	            if (validHex.isEmpty()) {
	                System.out.println("\nNo valid hexadecimal values found."
	                        + " Please scan a new QR code.\n");
	                continue;
	            }

	            System.out.println("\nVALID HEXADECIMAL VALUES ACCEPTED: "
	                    + joinList(validHex, ", "));

	            // --- Step 3 (A* feature): Repetition multiplier ---
	            int repetitions = promptRepetitionFactor();

	            // --- Step 4: Compute dance values and display summary ---
	            List<DanceValues> danceList = new ArrayList<>();
	            for (String hex : validHex) {
	                DanceValues dv = DanceCalculator.compute(hex);
	                danceList.add(dv);
	                sessionManager.addHexValue(hex);
	            }

	            displayConversionTable(danceList);

	            // --- Step 5: Wait for user to confirm, then dance ---
	            System.out.println("\nPress ENTER to begin the dance routine…");
	            waitForEnter();

	            System.out.println("\n================================================");
	            System.out.println("          SWIFTBOT DANCE IN PROGRESS");
	            System.out.println("================================================");

	            for (int rep = 0; rep < repetitions; rep++) {
	                if (repetitions > 1) {
	                    System.out.println("\n  ── Repetition " + (rep + 1)
	                            + " of " + repetitions + " ──");
	                }
	                for (DanceValues dv : danceList) {
	                    danceController.executeDanceRoutine(dv);
	                }
	            }

	            // Turn off LEDs after last routine
	            danceController.disableAllLights();
	            System.out.println("\n  LEDs switched OFF.");
	            System.out.println("\n================================================");
	            System.out.println("      All dance routines completed successfully.");
	            System.out.println("================================================");

	            // --- Step 6: Continue or exit ---
	            running = promptContinueOrExit();
	        }

	        // -------------------------------------------------------------------------
	        // Termination: sort & save
	        // -------------------------------------------------------------------------
	        displayTerminationScreen();
	        swiftBot.disableAllButtons();
	    }

	    // =========================================================================
	    // QR Code scanning
	    // =========================================================================

	    /**
	     * Prompts the user, captures a camera image, and decodes the QR code.
	     * Falls back to keyboard entry if the camera is unavailable or the QR
	     * cannot be decoded (useful for development/testing).
	     *
	     * @return The decoded QR code text, or {@code null} on failure.
	     */
	    private static String scanQRCode() {
	        System.out.println("\n================================================");
	        System.out.println("           QR CODE SCANNING");
	        System.out.println("================================================");
	        System.out.println("Position the QR code in front of the camera.");
	        System.out.println("QR CODE FORMAT:");
	        System.out.println("  • 1-5 hexadecimal values (each 1-2 digits, 0-9 / A-F)");
	        System.out.println("  • Values separated by '&'");
	        System.out.println("  • Example:  1F&3&C8&A");
	        System.out.println();
	        System.out.println("Press ENTER to scan (or type a value manually for testing):");

	        // Read a line – if the user just pressed ENTER, attempt camera scan
	        String line = keyboard.nextLine().trim();

	        if (!line.isEmpty()) {
	            // Developer/test mode: typed input accepted directly
	            return line;
	        }

	        // Camera scan
	        try {
	            BufferedImage img = swiftBot.getQRImage(ImageSize.SQUARE_480x480);
	            if (img == null) {
	                System.out.println("Camera returned no image.");
	                return null;
	            }
	            String decoded = swiftBot.decodeQRImage(img);
	            return (decoded != null && !decoded.trim().isEmpty()) ? decoded.trim() : null;
	        } catch (Exception e) {
	            System.out.println("QR scan error: " + e.getMessage());
	            return null;
	        }
	    }

	    // =========================================================================
	    // A* Feature – repetition multiplier
	    // =========================================================================

	    /**
	     * Prompts the user for a dance repetition factor between 1 and 3.
	     * Invalid input is rejected with an informative message and re-prompted.
	     *
	     * @return An integer 1, 2, or 3.
	     */
	    private static int promptRepetitionFactor() {
	        System.out.println();
	        System.out.println("================================================");
	        System.out.println("  A* FEATURE – Dance Repetition Multiplier");
	        System.out.println("================================================");
	        System.out.println("How many times should each routine be repeated?");
	        System.out.println("Enter 1, 2, or 3  (or press ENTER to skip – defaults to 1):");

	        while (true) {
	            String input = keyboard.nextLine().trim();

	            // Default to 1 if the user just presses ENTER
	            if (input.isEmpty()) {
	                System.out.println("Repetition factor set to 1 (default).");
	                return 1;
	            }

	            // Validate: must be a single digit 1, 2, or 3
	            if (input.length() == 1) {
	                char c = input.charAt(0);
	                if (c == '1' || c == '2' || c == '3') {
	                    int factor = c - '0';
	                    System.out.println("Repetition factor set to " + factor + ".");
	                    return factor;
	                }
	            }

	            System.out.println("Invalid input. Please enter 1, 2, or 3:");
	        }
	    }

	    // =========================================================================
	    // Continue / exit prompt (SwiftBot Y / X buttons)
	    // =========================================================================

	    /**
	     * Registers Y and X button handlers on the SwiftBot, then blocks until
	     * the user presses one of them.
	     *
	     * @return {@code true} if the user pressed Y (continue), {@code false} for X (exit).
	     */
	    private static boolean promptContinueOrExit() {
	        userButtonChoice = '\0'; // reset

	        System.out.println("\n================================================");
	        System.out.println("                 NEXT ACTION");
	        System.out.println("================================================");
	        System.out.println("Would you like to scan another QR code?");
	        System.out.println();
	        System.out.println("  Press  Y  on the SwiftBot to scan again.");
	        System.out.println("  Press  X  on the SwiftBot to exit.");
	        System.out.println();

	        // Enable buttons with lambda callbacks
	        swiftBot.enableButton(Button.Y, new ButtonFunction() {
	            @Override
	            public void run() {
	                userButtonChoice = 'Y';
	            }
	        });
	        swiftBot.enableButton(Button.X, new ButtonFunction() {
	            @Override
	            public void run() {
	                userButtonChoice = 'X';
	            }
	        });

	        // Spin-wait until a button is pressed (callback sets userButtonChoice)
	        while (userButtonChoice == '\0') {
	            try {
	                Thread.sleep(100);
	            } catch (InterruptedException e) {
	                Thread.currentThread().interrupt();
	                break;
	            }
	        }

	        // Disable buttons after choice is made
	        swiftBot.disableButton(Button.Y);
	        swiftBot.disableButton(Button.X);

	        char choice = userButtonChoice;
	        System.out.println("You pressed: " + choice);

	        return (choice == 'Y');
	    }

	    // =========================================================================
	    // Display helpers
	    // =========================================================================

	    /** Displays the startup / welcome screen. */
	    private static void displayStartupScreen() {
	        System.out.println();
	        System.out.println("================================================");
	        System.out.println("    SWIFTBOT DANCE PROGRAM  –  TASK 9");
	        System.out.println("================================================");
	        System.out.println("Welcome to the SwiftBot Dance System.");
	        System.out.println();
	        System.out.println("This program will:");
	        System.out.println("  • Convert hexadecimal values to Decimal, Octal,");
	        System.out.println("    and Binary");
	        System.out.println("  • Calculate SwiftBot speed and LED colour");
	        System.out.println("  • Generate and execute a structured dance routine");
	        System.out.println();
	        System.out.println("QR CODE INPUT FORMAT:");
	        System.out.println("  • 1 to 5 hexadecimal values");
	        System.out.println("  • Each value must be 1-2 characters (0-9, A-F)");
	        System.out.println("  • Values must be separated by '&'");
	        System.out.println("  • Example:  A&1F&3&9C");
	        System.out.println("================================================");
	    }

	    /**
	     * Displays the conversion table for all valid hex values in this round.
	     * Also prints the task-required one-line summary for each value.
	     */
	    private static void displayConversionTable(List<DanceValues> list) {
	        System.out.println("\n================================================");
	        System.out.println("       CONVERSION & MOVEMENT PREPARATION");
	        System.out.println("================================================");

	        for (DanceValues dv : list) {
	            System.out.println();
	            System.out.println("  >>> Processing Hexadecimal Value: " + dv.getHex());
	            System.out.println("  " + repeat('-', 44));
	            System.out.println("  NUMBER CONVERSIONS:");
	            System.out.println("    Decimal  : " + dv.getDecimal());
	            System.out.println("    Octal    : " + dv.getOctal());
	            System.out.println("    Binary   : " + dv.getBinary());
	            System.out.println();
	            System.out.println("  SPEED CALCULATION:");
	            System.out.println("    Base (octal)         : " + dv.getOctal());
	            if (dv.getOctal() < 50) {
	                System.out.println("    +50 threshold applied: "
	                        + dv.getOctal() + " + 50 = " + (dv.getOctal() + 50));
	            } else if (dv.getSpeed() == DanceCalculator.MAX_SPEED
	                    && dv.getOctal() > DanceCalculator.MAX_SPEED) {
	                System.out.println("    Capped at max speed  : " + DanceCalculator.MAX_SPEED);
	            }
	            System.out.println("    Final SwiftBot speed : " + dv.getSpeed());
	            System.out.println();
	            System.out.println("  LED COLOUR CALCULATION:");
	            System.out.println("    Red   = " + dv.getDecimal());
	            System.out.println("    Green = (" + dv.getDecimal() + " mod 80) x 3 = "
	                    + (dv.getDecimal() % 80) + " x 3 = " + dv.getGreenLED());
	            System.out.println("    Blue  = max("
	                    + dv.getRedLED() + ", " + dv.getGreenLED()
	                    + ") = " + dv.getBlueLED());
	            System.out.println();
	            // Required one-line summary format
	            System.out.println("  SUMMARY: " + dv);
	        }

	        System.out.println();
	        System.out.println("  All values processed successfully.");
	    }

	    /** Displays the termination / file-save screen. */
	    private static void displayTerminationScreen() {
	        System.out.println("\n================================================");
	        System.out.println("          PROGRAM TERMINATION");
	        System.out.println("================================================");
	        System.out.println("All hexadecimal values entered this session:");

	        List<String> all = sessionManager.getAllHexValues();
	        if (all.isEmpty()) {
	            System.out.println("  (none)");
	        } else {
	            for (String h : all) {
	                System.out.println("  " + h);
	            }
	        }

	        System.out.println();
	        System.out.println("Sorting and saving to file…");
	        String path = sessionManager.saveToFile();

	        if (path != null) {
	            System.out.println();
	            System.out.println("  ✔ Values sorted in ascending order");
	            System.out.println("  ✔ Saved to text file");
	            System.out.println();
	            System.out.println("FILE DETAILS:");
	            System.out.println("  File Name : swiftbot_hex_values.txt");
	            System.out.println("  File Path : " + path);
	        }

	        System.out.println();
	        System.out.println("Thank you for using the SwiftBot Dance Program.");
	        System.out.println("Program exited successfully.");
	        System.out.println("================================================");
	    }

	    // =========================================================================
	    // Utility helpers
	    // =========================================================================

	    /** Blocks until the user presses ENTER. */
	    private static void waitForEnter() {
	        keyboard.nextLine();
	    }

	    /** Joins a list of strings with the given separator. */
	    private static String joinList(List<String> list, String sep) {
	        StringBuilder sb = new StringBuilder();
	        for (int i = 0; i < list.size(); i++) {
	            if (i > 0) sb.append(sep);
	            sb.append(list.get(i));
	        }
	        return sb.toString();
	    }

	    /** Returns a string consisting of {@code n} repetitions of character {@code c}. */
	    private static String repeat(char c, int n) {
	        StringBuilder sb = new StringBuilder();
	        for (int i = 0; i < n; i++) sb.append(c);
	        return sb.toString();
	    }
	}
